Password for certificate: 12345

Necessary software:
Mac OS. You can use original Mac or use virtual machine with Mac OS.
Xcode and iTunes. You can download it from AppStore on your Mac.
iOS App Signer or any other apps for signing. You can download iOS App Signer here https://dantheman827.github.io/ios-app-signer/  

Step 1.
All steps should be done in Mac OS.
Download  Certificate.p12 and open it. Password 12345.

Step 2.
Download the desired app in .ipa format. You can find .ipa files on different forums or on apps libraries like this: https://appdb.to, https://www.iphonecake.com
Download mobile provision from FlekSt0re.

Step 3.
Open iOS App Signer. 
In field "Input file" choose .ipa file of app. In field "Signing Certificate" choose new certificate, which you added on Step 1. In field "Provisioning Profile" select "Choose custom file" and choose our mobile provision. 
Then press "start". Your app will be signed.

Step 4. 
Install your signed using iTunes with connected iOS-device or upload your file on https://www.diawi.com or https://www.installonair.com and download it directly from your phone. 